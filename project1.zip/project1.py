x = []

class Account():
    def __init__(self, nomor_akun, nama, saldo):
        self.nomor_akun = nomor_akun
        self.nama = nama
        self.saldo = saldo
    
    def akun(self):
        x.append(self.nomor_akun)
        x.append(self.nama)
        x.append(self.saldo)
        print(f'Nomor akun Anda {self.nomor_akun} dengan nama {self.nama}')

number = input("Masukkan nomor akun bank Anda: ")
name = input("Masukkan nama akun Anda: ")
saldo_anda = int(input("Masukkan jumlah saldo Anda: "))
proses = int(input("jumlah proses yang anda lakukan: "))
i = []

for n in range(1, proses + 1):
    print("1. Menyetor \n2. Menarik \n3. Memeriksa")
    pro = int(input("Masukkan proses yang Anda ingin lakukan: "))
    i.append(pro)

setoran = 0
tarik = 0
periksa = 0
n = 0
print(i)

class Bank():
    def __init__(self, nomor_akun, nama, saldo):
        self.nomor_akun = nomor_akun
        self.nama = nama
        self.saldo = saldo
    def info(self):
        for n in i:
            print(n)
            if n == 1:
                self.setoran = int(input("masukkan setoran yang Anda inginkan: "))
                self.saldo += self.setoran
                print(f'Jumlah saldo sekarang adalah: {self.saldo}')
            if n == 2:
                self.tarik = int(input("masukkan tarikan yang Anda inginkan: "))
                self.saldo -= self.tarik
                print(f'Jumlah saldo sekarang adalah: {self.saldo}')
            if n == 3:
                self.periksa = self.saldo
                print(f'Jumlah saldo sekarang adalah: {self.saldo}')
            
akun_obj = Account(number, name, saldo_anda)
bank_obj = Bank(number, name, saldo_anda)

akun_obj.akun()
bank_obj.info()
        
